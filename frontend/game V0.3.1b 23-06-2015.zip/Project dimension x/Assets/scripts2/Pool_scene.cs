﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

//playsound.PlayAudio(0);   Ontploffing
//playsound.PlayAudio(1);   start
//playsound.PlayAudio(2);   powerup
//playsound.PlayAudio(3);   aftel (plop)
//playsound.PlayAudio(4);   start
//playsound.PlayAudio(5);   background sound


/**
 * Main script of the pool scene.
 * Waits for the jsonApi to set startGame bool.
 **/
public class Pool_scene : MonoBehaviour {

	// Player username objects on stage
	public Text speler1_text;
	public Text speler2_text;
	public Text speler3_text;
	public Text speler4_text;

	// For moving the background
	public Transform background;

	// Used to play sounds and music
	AudioClass playsound = new AudioClass();

	// Countdown timer
	float queueCountdown = 5.0f;

	// Countdown textbox
	public Text countdownTxt;
	

	/**
	 * Initializing some stuff
	 **/
	void Start() {

		playsound.PlayAudio(5, "background_sound");  //start achtergrond geluid

		MainStatic.resetStatics();
	}
	
	/**
	 * Runs on every frame
	 **/
	void Update() {

		// Skip this if the game has not been started.
		if (MainStatic.startGame && !MainStatic.finishedGame) {

			tryLoadGame();
		}

		background.transform.Rotate (Vector3.forward * 1.5f * Time.deltaTime);
	}

	/**
	 * Clears player preference scores for new users
	 **/
	void clearPlayerScores() {

		foreach (Player player in MainStatic.players) {

			player.setScore(0);
		}
	}
	
	/**
	 * Fill the on stage objects with the usernames
	 **/
	void fillPlayerNameStageObjects() {

		speler1_text.text = MainStatic.players[0].getUsername();
		speler2_text.text = MainStatic.players[1].getUsername(); 
		speler3_text.text = MainStatic.players[2].getUsername();
		speler4_text.text = MainStatic.players[3].getUsername();
	}

	/**
	 * Loads the game when it is ready with fetching user data
	 **/
	void tryLoadGame() {

		this.clearPlayerScores ();
		this.fillPlayerNameStageObjects();

		if(queueCountdown >= 3.10f && queueCountdown <= 5.00f){   //check hoe dit uitwerkt op andere laptop

			countdownTxt.text = "Starting!";
			playsound.PlayAudio(3, "effects_sound");

		}

		if(queueCountdown >= 3.0f && queueCountdown <= 3.05f){

			countdownTxt.text = "Ready!";
			playsound.PlayAudio(3, "effects_sound");

		}

		if(queueCountdown >= 2.0f && queueCountdown <= 2.05f){

			countdownTxt.text = "Set!";
			playsound.PlayAudio(3, "effects_sound");

		}

		if(queueCountdown >= 1.0f && queueCountdown <= 1.05f){
			//print ("1");
			countdownTxt.text = "GO!";
			playsound.PlayAudio(4, "effects_sound");

		}

		// Decrement timer.
		queueCountdown -= Time.deltaTime;

		if (queueCountdown < -0.5f) {

			Application.LoadLevel(MainStatic.sceneGame);
		}
	}
}