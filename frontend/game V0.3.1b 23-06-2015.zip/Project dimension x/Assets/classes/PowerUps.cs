﻿using UnityEngine;
using System.Collections;


/**
 * Binded to Game scene, spawns powerUps
 **/
public class PowerUps : MonoBehaviour {

	/**
	 * PowerUP stage objects
	 **/
	public GameObject puSpeedUp;    // Speeds up the players' own shuttle.
	public GameObject puSlowDown;   // Slows everybody else down a bit.
	public GameObject puInverse;    // Inversed controls on opponents.
	public GameObject puInvincible; // Makes the player invincible for x seconds.
	
	/**
	 * PowerUP timers
	 **/
	public double tSpeedUp;
	public double tSlowDown;
	public double tInverse;
	public double tInvincible;

	/**
	 * Some timer threshold values
	 **/
	public double tPuInterval = 6; // Amount of secs. inbetween powerUP spawns.
	public static int tPuInverseThreshold = 2; // For how many secs. the controls need to be inversed.
	public static int tPuSlowDownThreshold = 2; // For how many secs. the 'enemies' need to be slower.
	public static int tPuSpeedUpThreshold = 3; // For how many secs. the player can hold the extra speed.
	public static int tPuInvincibleThreshold = 3; // For how many secs. to be invincible (cross lines).

	
	/**
	 * Spawns powerUps on given time intervals.
	 **/
	void Update () {
	
		// Speed up powerUP
		if (this.tSpeedUp > this.tPuInterval) {
			this.puSpawnSpeedUp();
			this.tSpeedUp = 0;
		}
		
		// Slow down powerUP
		if (this.tSlowDown > this.tPuInterval) {
			this.puSpawnSlowDown();
			this.tSlowDown = 0;
		}
		
		// Inversed controls powerUP
		if (this.tInverse > this.tPuInterval) {
			this.puSpawnInverse();
			this.tInverse = 0;
		}
		
		// Invincibility powerUP
		if (this.tInvincible > this.tPuInterval) {
			this.puSpawnInvincible();
			this.tInvincible = 0;
		}

		// Update spawn intervals.
		this.updateTimers();
	}

	/**
	 * Updates powerUP spawn timers
	 **/
	private void updateTimers() {

		this.tInverse += Time.deltaTime / Random.Range(1f, 3f);
		this.tInvincible += Time.deltaTime / Random.Range(1f, 3f);
		this.tSlowDown += Time.deltaTime / Random.Range(1f, 3f);
		this.tSpeedUp += Time.deltaTime / Random.Range(1f, 3f);
	}

	/**
	 * Spawns a new powerUP of type: speedUp
	 **/
	public void puSpawnSpeedUp() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puSpeedUp, new Vector3(x,y,0), Quaternion.identity);
	}
	
	/**
	 * Spawns a new powerUP of type: slowdown
	 **/
	public void puSpawnSlowDown() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puSlowDown, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}
	
	/**
	 * Spawns a new powerUP of type: Inversed controls
	 **/
	public void puSpawnInverse() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puInverse, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}
	
	/**
	 * Spawns a new powerUP of type: Invincible
	 **/
	public void puSpawnInvincible() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puInvincible, new Vector3 (x, y, 0), Quaternion.identity); //as GameObject;
	}
}
