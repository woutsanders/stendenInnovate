﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;


/**
 * Binded to the Game scene, handles all
 * main dynamic stuff like round increments.
 **/
public class MainDynamic : MonoBehaviour {

	/**
	 * Trail cube objects
	 **/
	public GameObject trailWhite;
	public GameObject trailRed;
	public GameObject trailBlue;
	public GameObject trailGreen;
	public GameObject trailYellow;

	/**
	 * Player spaceshuttle objects
	 **/
	public Transform player1;
	public Transform player2;
	public Transform player3;
	public Transform player4;

	/**
	 * Player username and score
	 * text objects for on the stage
	 **/
	public Text p1UsernameTxt;
	public Text p2UsernameTxt;
	public Text p3UsernameTxt;
	public Text p4UsernameTxt;
	public Text p1ScoreTxt;
	public Text p2ScoreTxt;
	public Text p3ScoreTxt;
	public Text p4ScoreTxt;

	/**
	 * For rotating the background
	 * (extra effect)
	 **/
	public Transform background;

	/**
	 * Handles the audio
	 **/
	public AudioClass playsound = new AudioClass();

	/**
	 * Objects and timers for the new lap animation
	 **/
	public Text roundTxt;
	public Transform lapAnimOuter;
	public Transform lapAnimMiddle;
	public Transform lapAnimInner;

	/**
	 * Poll timer for socket read
	 **/
	private double socketTimer;
	private double socketTimerInterval = 4; // Number of frames (not seconds)!

	/**
	 * Will be false when level is 
	 * being updated to prevent timing issues.
	 **/
	private bool updateLevel = true;

	/**
	 * Initializing the scene
	 **/
	void Start () {

		// Set player usernames on stage...
		this.p1UsernameTxt.text = MainStatic.players[0].getUsername().ToString();
		this.p2UsernameTxt.text = MainStatic.players[1].getUsername().ToString();
		this.p3UsernameTxt.text = MainStatic.players[2].getUsername().ToString();
		this.p4UsernameTxt.text = MainStatic.players[3].getUsername().ToString();

		// Before beginning, set direction of every player back to straight...
		foreach (Player player in MainStatic.players) {

			player.setDirection(0)
				.setTimerPuSpeedUp(10)
				.setTimerPuSlowDown(10)
				.setTimerPuInvincible(10)
				.setTimerPuInversed(10);
		}

		// Setup the necessary static components that we need (e.g. socket).
		MainStatic.setupSockets();

		playsound.PlayAudio(5, "background_sound"); // Start playing bg audio
		this.socketTimer = 0; // Reset socket timer.

		// Update round / lap text on stage and allow level update.
		roundTxt.text = MainStatic.round.ToString ();
		this.updateLevel = true;
	}
	
	/**
	 * Calls once a frame to update
	 * all game elements on current scene.
	 **/
	void Update () {

		// Increase the socket timer until threshold is met.
		this.socketTimer++;

		// Checks if there are still some players alive.
		this.checkAlivePlayers();

		// Rotate the background a bit for an extra gaming dimension.
		this.background.Rotate(Vector3.up * 1.3f * Time.deltaTime);

		// Timer is set to 0 if new lap is being initialized, so the circle will spin.
		if (MainStatic.tNewLapAnim < 3.5)
		{
			this.lapAnimOuter.transform.Rotate (Vector3.forward * 100 * Time.deltaTime);
			this.lapAnimMiddle.transform.Rotate (-Vector3.forward * 100 * Time.deltaTime);
			this.lapAnimInner.transform.Rotate (Vector3.forward * 100 * Time.deltaTime);
		}

		// Update all timers...
		this.updateTimers();

		// Update player movements...
		this.movePlayers();

		// Updates the score counters...
		this.updateScoreDisplay();
	}

	/**
	 * Updates the score counters
	 **/
	private void updateScoreDisplay() {

		this.p1ScoreTxt.text = MainStatic.players[0].getScore().ToString();
		this.p2ScoreTxt.text = MainStatic.players[1].getScore().ToString();
		this.p3ScoreTxt.text = MainStatic.players[2].getScore().ToString();
		this.p4ScoreTxt.text = MainStatic.players[3].getScore().ToString();
	}

	/**
	 * Increments the level number by one
	 **/
	private void levelUp() {

		MainStatic.round++;
	}

	/**
	 * Loads a new scene
	 **/
	private void loadLevel() {

		this.levelUp();

		if (MainStatic.round <= MainStatic.rounds)
			this.roundTxt.text = MainStatic.round.ToString();

		MainStatic.tNewLapAnim = 0;
		
		foreach (Player player in MainStatic.players) {
			
			player.setIsAlive(true);
		}

		Application.LoadLevel(MainStatic.sceneGame);
	}
	
	/**
	 * Loads the pool scene (player join lobby)
	 **/
	private void loadPool() {

		MainStatic.startGame = false;
		MainStatic.finishedGame = true;

		Application.LoadLevel(MainStatic.scenePool);
	}

	/**
	 * Checks whether there are still players alive,
	 * otherwise a new scene will load.
	 **/
	private void checkAlivePlayers() {

		int isAlive = 0;
		foreach (Player player in MainStatic.players) {
			
			if (player.isAlive())
				isAlive++;
		}

		// Checks whether the pool or a new round needs to be created.
		if (isAlive <= 1 && this.updateLevel) {

			this.updateLevel = false;

			if (MainStatic.round <= MainStatic.rounds) {

				Debug.Log("Round smaller than or equal to 3: " + MainStatic.round.ToString());

				this.loadLevel();
			}

			if (MainStatic.round > MainStatic.rounds) {

				Debug.Log("Round greater than 3: " + MainStatic.round.ToString());
				this.loadPool();
			}
		}
	}

	/**
	 * Updates the timers.
	 **/
	public void updateTimers() {

		MainStatic.start += Time.deltaTime;
		MainStatic.tNewLapAnim += Time.deltaTime;

		if (MainStatic.start > 3) {

			// Increment trail timers for spawn intervals.
			MainStatic.spawnTrailRate += Time.deltaTime;
			MainStatic.spawnTrailPause += Time.deltaTime;
		}

		// Set player specific timers.
		foreach (Player player in MainStatic.players) {

			double timerPuInvincible = player.getTimerPuInvincible();
			double timerPuInversed = player.getTimerPuInversed();
			double timerPuSpeedUp = player.getTimerPuSpeedUp();
			double timerPuSlowDown = player.getTimerPuSlowDown();

			player.setTimerPuInvincible(timerPuInvincible += Time.deltaTime);
			player.setTimerPuInversed(timerPuInversed += Time.deltaTime);
			player.setTimerPuSpeedUp(timerPuSpeedUp += Time.deltaTime);
			player.setTimerPuSlowDown(timerPuSlowDown += Time.deltaTime);
		}
	}

	/**
	 * Controls movement of players.
	 * Due to behavior of Unity, we explicitly need
	 * to specify the action for every player, which
	 * unfortunately results in duplicate code.
	 **/
	public void movePlayers() {

		if (MainStatic.start > 2 && this.updateLevel) {

			// Get player movements from server.
			this.getPlayerMovements();

			foreach(Player player in MainStatic.players) {

				int pId = player.getPlayerId();
				int dir = player.getDirection();

				// Player can't control if he is not alive
				if (!player.isAlive()) {

					continue;
				}

				if (pId == 1)
					this.player1.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				if (pId == 2)
					this.player2.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				if (pId == 3)
					this.player3.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				if (pId == 4)
					this.player4.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				// Inverse the controls if the inverse timer is lower than the threshold.
				if (player.getTimerPuInversed() < PowerUps.tPuInverseThreshold) { // Inversed controls

					if (dir == 1)
						dir = 2;

					if (dir == 2)
						dir = 1;
				}
				
				// Go left (or right if inversed)
				if (dir == 1) {
					if (pId == 1)
						this.player1.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);

					if (pId == 2)
						this.player2.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);

					if (pId == 3)
						this.player3.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);

					if (pId == 4)
						this.player4.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);
				}

				// Go right (or left if inversed)
				if (dir == 2) {

					if (pId == 1)
						this.player1.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
				
					if (pId == 2)
						this.player2.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
					
					if (pId == 3)
						this.player3.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
					
					if (pId == 4)
						this.player4.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
				}
			} // End-foreach
		} // End-if

		// Only execute if we are longer than 3 secs. in the scene and level update is allowed.
		if (MainStatic.start > 3 && this.updateLevel) {

			if (MainStatic.spawnTrailRate > MainStatic.spawnTrailInterval) {
				if (MainStatic.spawnTrailPause < 3) {

					foreach(Player player in MainStatic.players) {

						if (player.isAlive()) {

							int pId = player.getPlayerId();

							if (pId == 1)
								Instantiate(this.getCube(player.getColor()), this.player1.position, this.player1.rotation);

							if (pId == 2)
								Instantiate(this.getCube(player.getColor()), this.player2.position, this.player2.rotation);

							if (pId == 3)
								Instantiate(this.getCube(player.getColor()), this.player3.position, this.player3.rotation);

							if (pId == 4)
								Instantiate(this.getCube(player.getColor()), this.player4.position, this.player4.rotation);
						}
					}

					MainStatic.spawnTrailRate = 0;

				} else if (MainStatic.spawnTrailPause > 3.5) {

					MainStatic.spawnTrailPause = 0;
				}
			} // End-if trail spawn decision
		} // End-if
	}

	/**
	 * Returns the trail object to spawn,
	 * dependent on the color of the player.
	 **/
	private GameObject getCube(Color color) {

		if (color == Color.red) {

			return this.trailRed;
		}
		else if (color == Color.green) {

			return this.trailGreen;
		}
		else if (color == Color.yellow) {

			return this.trailYellow;
		}
		else if (color == Color.blue) {

			return this.trailBlue;
		}
		else if (color == Color.white) {

			return this.trailWhite;
		}

		// The default if no match is found.
		return this.trailRed;
	}

	/**
	 * Gets player movements from the socket
	 * and updates player objects accordingly.
	 **/
	private void getPlayerMovements() {

		if (this.socketTimer < this.socketTimerInterval)
			return;

		this.socketTimer = 0;

		// Get raw data of movements of all players...
		string movements = MainStatic.socketReader.read();

		// Explode it...
		string[] playerData = movements.Split(new char[] {','});

		for (int i = 0; i < MainStatic.players.Count; i++) {

			// Get player control string...
			string[] hashControl = playerData[i].Split(new char[] {':'});

			// If hash from server is same as that from player, continue.
			if (hashControl[0] == MainStatic.players[i].getHash()) {

				// Set direction of player to that from server.
				MainStatic.players[i].setDirection(int.Parse(hashControl[1]));
			}
		}
	}
}
