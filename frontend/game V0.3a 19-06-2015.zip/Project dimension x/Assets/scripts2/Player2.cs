using UnityEngine;
using System.Collections;

public class Player2 : MonoBehaviour {
	
	private int pId;
	
	// MOVED TO PLAYER CLASS (TBM)
	public Light light;
	public static float PU_Light = -1f; //powerup - sneller
	public static float PD_Light = -1f; //powerup - langzamer
	public static float PI_Light = -1f; //powerup - inverse
	public static float PG_Light = -1f; //powerup - ghost
	
	void Start() 
	{
		this.pId = MainStatic.players[1].getPlayerId();
		
		light = gameObject.GetComponent<Light> ();
		light.enabled = false;
		light.color = Color.white;
		light.range = 1;
	}
	
	void Update ()
	{
		// PowerUP light timers.
		PU_Light -= Time.deltaTime;
		PD_Light -= Time.deltaTime;
		PI_Light -= Time.deltaTime;
		PG_Light -= Time.deltaTime;
		
		//PowerUP lights on or off?
		if (PU_Light > 0 || PD_Light > 0 || PI_Light > 0 || PG_Light > 0) {
			light.enabled = true;
		}
		else{
			light.enabled = false;
		}
		
		//Light of puSpeedUp
		if (PU_Light > 0) {
			//	light.enabled = true;
			light.color = Color.green;
			light.range = PU_Light;
		}
		
		// Light of puSlowDown
		if (PD_Light > 0) {
			light.enabled = true;
			light.color = Color.red;
			light.range = PD_Light;
		}
		
		//Light of puInverse
		if (PI_Light > 0) {
			light.enabled = true;
			light.color = Color.yellow;
			light.range = PI_Light;
		}
		
		// Light of puInvincible
		if (PG_Light > 0) {
			light.enabled = true;
			light.color = Color.magenta;
			light.range = PG_Light;
		}
		
		// puSpeedUp
		if (MainStatic.players[this.pId - 1].getSpeed() > 3) {
			
			double tSpeedUp = MainStatic.players[this.pId - 1].getTimerPuSpeedUp();
			
			MainStatic.players[this.pId - 1].setTimerPuSpeedUp(tSpeedUp += Time.deltaTime);
			
			if(MainStatic.players[this.pId - 1].getTimerPuSpeedUp() > 2)
				MainStatic.players[this.pId - 1].setSpeed(3);
		}
		
		// puSlowDown other players
		if (MainStatic.players[this.pId - 1].getSpeed() < 3 ) {
			
			double tSlowDown = MainStatic.players[this.pId - 1].getTimerPuSlowDown();
			MainStatic.players[this.pId - 1].setTimerPuSlowDown(tSlowDown += Time.deltaTime);
			
			if(MainStatic.players[this.pId - 1].getTimerPuSlowDown() > 2) {
				
				foreach (Player player in MainStatic.players) {
					
					if (player.getPlayerId() == this.pId)
						continue;
					
					player.setSpeed(3);
				}
			}
		}
	}
	
	public void OnTriggerEnter(Collider other)
	{
		//powerup1 - zelf sneller
		if (other.gameObject.name == "MySphere" + "(Clone)") {
			MainStatic.players[this.pId - 1].setTimerPuSpeedUp(0);
			MainStatic.players[this.pId - 1].setSpeed(4);
			PU_Light = 3f;
		}
		//powerup2 - enemy langzamer
		if (other.gameObject.name == "SlowDown" + "(Clone)") {
			
			foreach (Player player in MainStatic.players) {
				
				if (player.getPlayerId() == this.pId)
					continue;
				
				player.setTimerPuSlowDown(0);
				player.setSpeed(2);
			}
			
			Player1.PD_Light = 3f;
			Player3.PD_Light = 3f;
			Player4.PD_Light = 3f;
			
		}
		//powerup 3 - inversed controls
		if (other.gameObject.name == "Inverse" + "(Clone)") {
			
			foreach (Player player in MainStatic.players) {
				
				if (player.getPlayerId() == this.pId)
					continue;
				
				player.setTimerPuInversed(0);
			}
			
			Player1.PI_Light = 3f;
			Player3.PI_Light = 3f;
			Player4.PI_Light = 3f;
		}
		//powerup 4 - invincibility
		if (other.gameObject.name == "NoStops" + "(Clone)") {
			
			MainStatic.players[this.pId - 1].setTimerPuInvincible(0);
			PG_Light = 3f;
		}
	}
}
