using UnityEngine;
using System.Collections;

public class SpawnPowerUps : MonoBehaviour {

	public GameObject Explosion;

	AudioClass playsound = new AudioClass();



	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.name == "Player1" || other.gameObject.name == "Player2" || 
		    other.gameObject.name == "Player3" || other.gameObject.name == "Player4")  
		{
			playsound.PlayAudio(2, "soundeffect_powerup");

			Instantiate (Explosion, transform.position, new Quaternion());
			Destroy(gameObject);
		}
	}
}

		



