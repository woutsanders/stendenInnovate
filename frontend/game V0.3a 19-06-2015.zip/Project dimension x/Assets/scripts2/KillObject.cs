﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class KillObject : MonoBehaviour {
	
	public double timer;

	AudioClass playsound = new AudioClass();
	
	void Update () {

		timer += Time.deltaTime;
	}
	
	void OnTriggerEnter(Collider other) {

		foreach (Player player in MainStatic.players) {

			if (player.isAlive()) {

				if (player.getTimerPuInvincible() > PowerUps.tPuInvincibleThreshold
				    && this.timer > 0.07
				    && other.gameObject.name == "Player" + player.getPlayerId())
				{
					MainStatic.addScore(MainStatic.scoreAmount);
					player.setIsAlive(false);
					playsound.PlayAudio(0, "soundeffect_explosion");
				}
			}
		} // End-foreach
	}
	
}
