﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

//playsound.PlayAudio(0);   Ontploffing
//playsound.PlayAudio(1);   start
//playsound.PlayAudio(2);   powerup
//playsound.PlayAudio(3);   aftel (plop)
//playsound.PlayAudio(4);   start
//playsound.PlayAudio(5);   background sound

public class Pool_scene : MonoBehaviour {
	
	public int Speler1_ID;
	public int Speler2_ID;
	public int Speler3_ID;
	public int Speler4_ID;
	
	public string Speler1_Username;
	public string Speler2_Username;
	public string Speler3_Username;
	public string Speler4_Username;
	
	public Text speler1_text;
	public Text speler2_text;
	public Text speler3_text;
	public Text speler4_text;

	// The JSON API to communicate with.
	public JsonApi jsonApi;
	
	public Transform background;

	AudioClass playsound = new AudioClass();
	
	float queueCountdown = 5.0f;

	public Text countdownTxt;

	/**
	 * Initializing some stuff
	 **/
	void Start() {

		this.jsonApi = new JsonApi();
		playsound.PlayAudio(5, "background_sound");  //start achtergrond geluid
		
		PlayerPrefs.SetInt("LevelNummer", 0);
		MainStatic.tNewLapAnim = 0;
		MainStatic.round = 0;
	}
	
	/**
	 * Runs on every frame
	 **/
	void Update() {

		tryLoadGame();
		background.transform.Rotate (Vector3.forward * 2 * Time.deltaTime);
	}

	/**
	 * Clears player preference scores for new users
	 **/
	void clearPlayerPrefScores(){

		PlayerPrefs.SetInt ("Speler1_score", 0);
		PlayerPrefs.SetInt ("Speler2_score", 0);
		PlayerPrefs.SetInt ("Speler3_score", 0);
		PlayerPrefs.SetInt ("Speler4_score", 0);
	}
	
	
	/**
	 * Sets some player preferences for on stage objects.
	 **/
	void setPlayerPrefs() {

		foreach (Player player in MainStatic.players) {

			PlayerPrefs.SetInt("Speler" + player.getPlayerId() + "_ID", player.getPlayerId());
			PlayerPrefs.SetString("Speler" + player.getPlayerId() + "_Username", player.getUsername());
		}
	}

	/**
	 * Puts the player preferences in some variables.
	 **/
	void getValuesFromPlayerPrefs() {

		Speler1_ID = PlayerPrefs.GetInt("Speler1_ID");
		Speler1_Username = PlayerPrefs.GetString("Speler1_Username");
		
		Speler2_ID = PlayerPrefs.GetInt("Speler2_ID");
		Speler2_Username = PlayerPrefs.GetString("Speler2_Username");
		
		Speler3_ID = PlayerPrefs.GetInt("Speler3_ID");
		Speler3_Username = PlayerPrefs.GetString("Speler3_Username");
		
		Speler4_ID = PlayerPrefs.GetInt("Speler4_ID");
		Speler4_Username = PlayerPrefs.GetString("Speler4_Username");
	}
	
	/**
	 * Fill the on stage objects with the usernames
	 **/
	void fillPlayerNameStageObjects() {

		speler1_text.text = Speler1_Username; 
		speler2_text.text = Speler2_Username; 
		speler3_text.text = Speler3_Username; 
		speler4_text.text = Speler4_Username;

		countdownTxt.text = "Starting";
	}

	/**
	 * Loads the game when it is ready with fetching user data
	 **/
	void tryLoadGame() {

		if (!MainStatic.startGame)
			return;

		this.clearPlayerPrefScores();
		this.setPlayerPrefs();
		this.getValuesFromPlayerPrefs();
		this.fillPlayerNameStageObjects();

		if(queueCountdown == 5f){
			//print ("5");
			countdownTxt.text = "4";
			//playsound.PlayAudio(3);
			playsound.PlayAudio(3, "effects_sound");
		}

		if(queueCountdown >= 4.0f && queueCountdown <= 4.05f){   //check hoe dit uitwerkt op andere laptop
			//print ("4");
			countdownTxt.text = "3";
			playsound.PlayAudio(3, "effects_sound");

		}

		if(queueCountdown >= 3.0f && queueCountdown <= 3.05f){
			//print ("3");
			countdownTxt.text = "2";
			playsound.PlayAudio(3, "effects_sound");

		}

		if(queueCountdown >= 2.0f && queueCountdown <= 2.05f){
			//print ("2");
			countdownTxt.text = "1";
			playsound.PlayAudio(3, "effects_sound");

		}

		if(queueCountdown >= 1.0f && queueCountdown <= 1.05f){
			//print ("1");
			countdownTxt.text = "GO!";
			playsound.PlayAudio(4, "effects_sound");

		}

		queueCountdown = queueCountdown - Time.deltaTime;

		if (queueCountdown < 0) {
			Application.LoadLevel (0);
		}
	}
}