﻿using UnityEngine;
using System.Collections;
/* Patrick luchies
 * Datum: 16-6-2015
*/


public class AudioClass{
	
	public void PlayAudio(int clip, string audioobject)
	{
		AudioSource audiosource;
		AudioClip[] geluid;
		audiosource = Camera.main.transform.Find (audioobject).GetComponent<AudioSource> ();
		geluid = new AudioClip[]
		{

			//Hier volgt en array. Begin bij 0

			//Voor de game level
			(AudioClip)Resources.Load ("geluid/ontplof") as AudioClip,     //Zodra de speler dood gaat  
			(AudioClip)Resources.Load ("geluid/background_spacesound") as AudioClip,  //Achtergrond muziek  
			(AudioClip)Resources.Load ("geluid/powerup") as AudioClip,	   //bij het pakken van een powerup 
			//(AudioClip)Resources.Load ("geluid/snoop") as AudioClip,	   //Smoke weed everyday

			//Voor de pool scene
			(AudioClip)Resources.Load ("geluid/aftel") as AudioClip,    //Aftel geluid
			(AudioClip)Resources.Load ("geluid/start") as AudioClip,	   //Geluid als aftellen klaar is
			(AudioClip)Resources.Load ("geluid/background_poolscene") as AudioClip	       //Achtergrond geluid voor de pool scene
		};
		audiosource.clip = geluid [clip];
		audiosource.Play ();
	}
}