﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class MainStatic {

	/**
	 * Player (and related) objects
	 **/
	public static List<Player> players;

	public static bool spawnTrail = false;
	public static double spawnTrailRate; // Number of cubes to spawn in seconds.
	public static double spawnTrailPause; // How long to wait before leaving a hole.
	public static double spawnTrailInterval = 0.08; // The fixed interval for timer.

	/**
	 * Unity3D On Stage objects
	 **/
	public static int turn = 300;
	public static Transform speler1;
	public static Transform speler2;
	public static Transform speler3;
	public static Transform speler4;
	public static Transform background;

	/**
	 * Socket data for tunneling controls.
	 **/
	public static SocketHelper socketWriter;
	public static SocketHelper socketReader;
	public static string socketHost = "woutsanders.com";
	public static int socketWriterPort = 9990;
	public static int socketReaderPort = 9991;

	/**
	 * Some game starting statuses and timers
	 **/
	public static bool startGame = false; // To start, or not to start the game :)
	public static double start; // Timer to delay some animations after start.
	public static int round = 0; // How many rounds / laps have been made.

	public static double tNewLapAnim = 4;
	
	// Score increment
	public static int scoreAmount = 10;


	/**
	 * Sets some things that really need to.
	 **/
	public static void setupStatics() {

		MainStatic.socketWriter = new SocketHelper(MainStatic.socketHost, MainStatic.socketWriterPort);
		MainStatic.socketReader = new SocketHelper(MainStatic.socketHost, MainStatic.socketReaderPort);
	}

	/**
	 * Adds score to players
	 **/
	public static void addScore(int amount) {

		foreach (Player player in MainStatic.players) {

			if (player.isAlive()) {
			
				int pId = player.getPlayerId();
				int score = PlayerPrefs.GetInt("Speler" + pId + "_score");
				player.setScore (score + amount);
			}
		}
	}
}