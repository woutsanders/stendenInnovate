﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.IO;
using System.Net.Sockets;

public class SocketHelper {

	private bool socketReady;
	private TcpClient socket;
	private NetworkStream socketStream;
	private StreamWriter socketWriter;
	private StreamReader socketReader;
	private string host;
	private int port;


	/**
	 * Overloader in case different host and port is used.
	 **/
	public SocketHelper(string host, int port) { 

		this.host = host;
		this.port = port;

		this.socketReady = false;

		this.setup();
	}

	private void setup() {

		try {
			this.socket = new TcpClient(this.host, this.port);
		} catch (SocketException e) {
			Debug.Log(e.ToString());
			return;
		}

		try {
			this.socketWriter = new StreamWriter(this.socket.GetStream());
			this.socketReader = new StreamReader(this.socket.GetStream());
			this.socketReady = true;
		} catch (NullReferenceException e) {
			Debug.Log(e.ToString());
			this.socketReady = false;
		}
	}

	/**
	 * Writes to the socket
	 **/
	public void write(string toWrite) {
		
		if (!this.checkSocket())
			this.setup();
		
		String data = toWrite + "\r\n";
		Debug.Log ("Sending: " + data);
		this.socketWriter.Write(data);
		this.socketWriter.Flush();
		this.close ();
	}

	/**
	 * Reads the socket
	 **/
	public String read() {

		if (!this.checkSocket())
			this.setup();

//		if (!this.socket.GetStream().DataAvailable) {
//
//			return "NULL";
//		}

		string message = this.socketReader.ReadLine();
		this.close ();
		return message;
	}

	/**
	 * Closes the socket.
	 **/
	public void close() {

		if (!this.checkSocket())
			return;

		this.socketWriter.Close();
		this.socketReader.Close();
		this.socket.Close();
		this.socketReady = false;
	}

	/**
	 * Checks whether socket is accessible.
	 **/
	private bool checkSocket() {

		if (!this.socketReady || !this.socket.GetStream().CanRead) {
			return false;
		}

		return true;
	}
}
