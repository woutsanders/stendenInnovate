﻿using UnityEngine;
using System.Collections;

public class PowerUps : MonoBehaviour {

	/**
	 * PowerUP stage objects
	 **/
	public GameObject puSpeedUp;    // Speeds up the players' own shuttle.
	public GameObject puSlowDown;   // Slows everybody else down a bit.
	public GameObject puInverse;    // Inversed controls on opponents.
	public GameObject puInvincible; // Makes the player invincible for x seconds.
	
	/**
	 * PowerUP timers
	 **/
	public double tSpeedUp;
	public double tSlowDown;
	public double tInverse;
	public double tInvincible;

	/**
	 * Some timer threshold values
	 **/
	public double tPuInterval = 3; // Amount of secs. inbetween powerUP spawns.
	public static int puInverseThreshold = 2; // For how many secs. the controls need to be inversed.
	public static int tPuInvincibleThreshold = 3; // For how many secs. to be invincible (cross lines).

	
	// Update is called once per frame
	void Update () {
	
		// Speed up powerUP
		if (this.tSpeedUp > this.tPuInterval) {
			this.puSpawnSpeedUp();
			this.tSpeedUp = 0;
		}
		
		// Slow down powerUP
		if (this.tSlowDown > this.tPuInterval) {
			this.puSpawnSlowDown();
			this.tSlowDown = 0;
		}
		
		// Inversed controls powerUP
		if (this.tInverse > this.tPuInterval) {
			this.puSpawnInverse();
			this.tInverse = 0;
		}
		
		// Invincibility powerUP
		if (this.tInvincible > this.tPuInterval) {
			this.puSpawnInvincible();
			this.tInvincible = 0;
		}

		// Update spawn intervals.
		this.updateTimers();
	}

	/**
	 * Updates powerUP spawn timers
	 **/
	private void updateTimers() {

		this.tInverse += Time.deltaTime;
		this.tInvincible += Time.deltaTime;
		this.tSlowDown += Time.deltaTime;
		this.tSpeedUp += Time.deltaTime;
	}

	/**
	 * Spawns a new powerUP of type: speedUp
	 **/
	public void puSpawnSpeedUp() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puSpeedUp, new Vector3(x,y,0), Quaternion.identity);
	}
	
	/**
	 * Spawns a new powerUP of type: slowdown
	 **/
	public void puSpawnSlowDown() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puSlowDown, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}
	
	/**
	 * Spawns a new powerUP of type: Inversed controls
	 **/
	public void puSpawnInverse() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puInverse, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}
	
	/**
	 * Spawns a new powerUP of type: Invincible
	 **/
	public void puSpawnInvincible() {
		
		// Set coordinates and put PU on stage.
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(this.puInvincible, new Vector3 (x, y, 0), Quaternion.identity); //as GameObject;
	}
}
