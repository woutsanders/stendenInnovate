﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class MainDynamic : MonoBehaviour {

	/**
	 * Trail objects
	 **/
	public GameObject trailWhite;  // White trail cube
	public GameObject trailRed; // Red trail cube
	public GameObject trailBlue; // Blue trail cube
	public GameObject trailGreen; // Green trail cube
	public GameObject trailYellow; // Yellow trail cube

	/**
	 * Player shuttle objects
	 **/
	public Transform player1; // Player 1 shuttle
	public Transform player2; // Player 2 shuttle
	public Transform player3; // Player 3 shuttle
	public Transform player4; // Player 4 shuttle

	/**
	 * Player username text objects for on the stage
	 **/
	public Text p1UsernameTxt;
	public Text p2UsernameTxt;
	public Text p3UsernameTxt;
	public Text p4UsernameTxt;

	// Dynamic background (rotation)
	public Transform background;

	// Plays the background music
	public AudioClass playsound = new AudioClass();

	/**
	 * Wrapper for the powerUPs
	 **/
	public PowerUps powerUps;

	/**
	 * Objects and timers for the new lap animation
	 **/
	public Text roundTxt;
	public Transform lapAnimOuter;
	public Transform lapAnimMiddle;
	public Transform lapAnimInner;

	private double socketTimer;
	private double socketTimerInterval = 15;

	// Use this for initialization
	void Start () {

		// Setup the necessary static components (e.g. socket).
		MainStatic.setupStatics();

		playsound.PlayAudio(5, "background_sound");
		this.levelUp();
		this.powerUps = new PowerUps();
		this.socketTimer = 0;
	}
	
	// Update is called once per frame
	void Update () {

		this.socketTimer++;

		// Checks if there are still some players alive.
		this.checkAlivePlayers();

		// Rotate the background a bit.
		this.background.Rotate(Vector3.up * 1.5f * Time.deltaTime);

		// Timer is set to 0 if new lap is being initialized, so the circle will spin.
		if (MainStatic.tNewLapAnim < 3.5)
		{
			this.lapAnimOuter.transform.Rotate (Vector3.forward * 100 * Time.deltaTime);
			this.lapAnimMiddle.transform.Rotate (-Vector3.forward * 100 * Time.deltaTime);
			this.lapAnimInner.transform.Rotate (Vector3.forward * 100 * Time.deltaTime);
		}

		// Update all timers...
		this.updateTimers();

		// Update player movements...
		this.movePlayers();
	}

	/**
	 * Increments the level number by one
	 **/
	private void levelUp() {
		MainStatic.round = PlayerPrefs.GetInt("LevelNummer");
		MainStatic.round++;
		PlayerPrefs.SetInt("LevelNummer" , MainStatic.round);
		roundTxt.text = PlayerPrefs.GetInt("LevelNummer").ToString();
	}

	/**
	 * Loads a new scene
	 **/
	private void loadLevel() {
		
		MainStatic.tNewLapAnim = 0;
		
		foreach (Player player in MainStatic.players) {
			
			player.setIsAlive(true);
		}
		
		Application.LoadLevel(0);
	}
	
	/**
	 * Loads the pool scene (player join splash)
	 **/
	private void loadPool() {
		
		Application.LoadLevel(1);
	}

	/**
	 * Checks whether there are still players alive,
	 * otherwise a new scene will load.
	 **/
	private void checkAlivePlayers() {

		int isAlive = 0;
		foreach (Player player in MainStatic.players) {
			
			if (player.isAlive())
				isAlive++;
		}
		
		// Checks whether the pool or a new round needs to be created.
		if (isAlive <= 1) {

			if (MainStatic.round < 3) {
				this.loadLevel();
			}

			if (MainStatic.round >= 3) {	
				this.loadPool();
			}
		}
	}

	/**
	 * Updates the timers.
	 **/
	public void updateTimers() {

		MainStatic.start += Time.deltaTime;
		MainStatic.tNewLapAnim += Time.deltaTime;

		if (MainStatic.start > 3) {

			// Increment trail timers for spawn intervals.
			MainStatic.spawnTrailRate += Time.deltaTime;
			MainStatic.spawnTrailPause += Time.deltaTime;
		}

		// Set player specific timers.
		foreach (Player player in MainStatic.players) {

			double timerPuInvincible = player.getTimerPuInvincible();
			double timerPuInversed = player.getTimerPuInversed();
			double timerPuSpeedUp = player.getTimerPuSpeedUp();
			double timerPuSlowDown = player.getTimerPuSlowDown();

			player.setTimerPuInvincible(timerPuInvincible += Time.deltaTime);
			player.setTimerPuInversed(timerPuInversed += Time.deltaTime);
			player.setTimerPuSpeedUp(timerPuSpeedUp += Time.deltaTime);
			player.setTimerPuSlowDown(timerPuSlowDown += Time.deltaTime);
		}
	}

	/**
	 * Controls movement of players
	 **/
	public void movePlayers() {

		if (MainStatic.start > 2) {

			// Get player movements from server.
			this.getPlayerMovements();

			foreach(Player player in MainStatic.players) {

				int pId = player.getPlayerId();
				int dir = player.getDirection();

				// Player can't control if he is not alive
				if (!player.isAlive()) {

					continue;
				}

				if (pId == 1)
					this.player1.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				if (pId == 2)
					this.player2.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				if (pId == 3)
					this.player3.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				if (pId == 4)
					this.player4.Translate(Vector3.up * (player.getSpeed() + 1) * Time.deltaTime);

				// Inverse the controls if the inverse timer is lower than the threshold.
				if (player.getTimerPuInversed() < PowerUps.puInverseThreshold) { // Inversed controls

					if (dir == 1)
						dir = 2;

					if (dir == 2)
						dir = 1;
				}
				
				// Go left (or right if inversed)
				if (dir == 1) {
					if (pId == 1)
						this.player1.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);

					if (pId == 2)
						this.player2.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);

					if (pId == 3)
						this.player3.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);

					if (pId == 4)
						this.player4.Rotate(Vector3.forward * MainStatic.turn * Time.deltaTime);
				}

				// Go right (or left if inversed)
				if (dir == 2) {

					if (pId == 1)
						this.player1.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
				
					if (pId == 2)
						this.player2.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
					
					if (pId == 3)
						this.player3.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
					
					if (pId == 4)
						this.player4.Rotate(-Vector3.forward * MainStatic.turn * Time.deltaTime);
				}
			} // End-foreach
		} // End-if


		if (MainStatic.start > 3) {

			if (MainStatic.spawnTrailRate > MainStatic.spawnTrailInterval) {
				if (MainStatic.spawnTrailPause < 3) {

					foreach(Player player in MainStatic.players) {

						if (player.isAlive()) {

							int pId = player.getPlayerId();

							if (pId == 1)
								Instantiate(this.trailColorCheck(player.getColor()), this.player1.position, this.player1.rotation);

							if (pId == 2)
								Instantiate(this.trailColorCheck(player.getColor()), this.player2.position, this.player2.rotation);

							if (pId == 3)
								Instantiate(this.trailColorCheck(player.getColor()), this.player3.position, this.player3.rotation);

							if (pId == 4)
								Instantiate(this.trailColorCheck(player.getColor()), this.player4.position, this.player4.rotation);
						}
					}

					MainStatic.spawnTrailRate = 0;

				} else if (MainStatic.spawnTrailPause > 3.5) {

					MainStatic.spawnTrailPause = 0;
				}
			}
		}
	}

	/**
	 * Returns the trail object to spawn, dependent on the color of the player.
	 **/
	private GameObject trailColorCheck(Color color) {

		if (color == Color.red) {

			return this.trailRed;
		}
		else if (color == Color.green) {

			return this.trailGreen;
		}
		else if (color == Color.yellow) {

			return this.trailYellow;
		}
		else if (color == Color.blue) {

			return this.trailBlue;
		}
		else if (color == Color.white) {

			return this.trailWhite;
		}

		// The default if no match is found.
		return this.trailRed;
	}

	/**
	 * Gets player movements from the socket.
	 **/
	private void getPlayerMovements() {

		if (this.socketTimer < this.socketTimerInterval)
			return;

		this.socketTimer = 0;

		// Get raw data...
		string movements = MainStatic.socketReader.read();

		// Explode it...
		string[] playerData = movements.Split(new char[] {','});

		for (int i = 0; i < MainStatic.players.Count; i++) {

			// Get player control string...
			string[] hashControl = playerData[i].Split(new char[] {':'});

			// If hash from server is same as that from player, continue.
			if (hashControl[0] == MainStatic.players[i].getHash()) {

				// Set direction of player to that from server.
				MainStatic.players[i].setDirection(int.Parse(hashControl[1]));
			}
		}
	}
}
