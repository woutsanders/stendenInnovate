﻿using UnityEngine;
using UnityEngine.UI;
using SimpleJSON;
using System;
using System.Collections;
using System.Collections.Generic;

//http://stackoverflow.com/questions/18833090/how-to-display-data-from-json-with-simplejson-c-sharp
//http://wiki.unity3d.com/index.php/SimpleJSON

public class JsonApi : MonoBehaviour {

	// Some important stuff.
	private string getUserDataUrl = "http://woutsanders.com/stendenInnovate/backend/web/api/unity/userdata";
	private bool noContent = true;
	private bool sentScores = false;
	private double tInterval = 3;
	private double tIntervalDelta = 0;
	private bool dataReceived = false;
	
	//IEnumerator WaitForRequest(WWW www)
	IEnumerator getUserDataFromUri()
	{
		WWW retrieveUserData = new WWW (this.getUserDataUrl);
		yield return retrieveUserData;

		if (retrieveUserData.error == null)
		{
			JSONNode playerData = JSON.Parse(retrieveUserData.text);

			if (playerData != null) {

				this.dataReceived = true;
				MainStatic.players = new List<Player>();

				for (int i = 1; i < 5; i++) {

					Debug.Log(playerData["player" + i]["username"].Value);

					Player player = new Player();
					player
						.setUsername(playerData["player" + i]["username"].Value)
						.setHash(playerData["player" + i]["hash"].Value)
						.setUserId(playerData["player" + i]["id"].AsInt)
						.setPlayerId(i)
						.setColor(playerData["player" + i]["color"].Value)
						.setDirection(0);

					MainStatic.players.Add(player);
				}

				string sWrite = "";
				foreach (Player player in MainStatic.players) {

					sWrite += player.getHash();
					sWrite += ",";
				}

				// Write user data to server for authentication of websocket users.
				MainStatic.socketWriter.write(sWrite);

				// Start the game.
				MainStatic.startGame = true;
				this.noContent = false;

			} else {

				// Loop through response headers if response was null.
				foreach(KeyValuePair<string, string> entry in retrieveUserData.responseHeaders) {

					if (entry.Key == "STATUS") {

						string[] parts = entry.Value.Split(new char[] {' '});
						int statusCode = int.Parse(parts[1]);

						if (statusCode == 204) {
				
							this.noContent = true;
							Debug.Log("No playerdata available on server, try again later");
						}
					}
				}
			}

		} else {

			Debug.Log(retrieveUserData.error);
		}
	}

	void Start() {

		//Setup some necessary static components (e.g. socket).
		MainStatic.setupStatics();
	}

	void Update() {

		this.pollForUserData();
	}

	private void pollForUserData() {

		if (MainStatic.startGame)
			return;

		// Increment timer var.
		this.tIntervalDelta += Time.deltaTime;

		// Wait a few seconds inbetween AJAX calls
		if (this.tIntervalDelta >= this.tInterval) {

			// Reset timer.
			this.tIntervalDelta = 0;

			// Before calling server, make sure no game or content was loaded / received.
			if (!MainStatic.startGame && this.noContent && !this.dataReceived) {

				// Run async JSON call...
				StartCoroutine(this.getUserDataFromUri());
			}
		}
	}
}






