﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	/**
	 * Attributes that are used for controlling the trail
	 * which the user leaves behind when playing.
	 **/
	private GameObject MyCube; // Trail cube
	private GameObject shuttle; // Player shuttle object
	private Transform trans; // Player shuttle

	// Contains the timer value of the invincible powerUP
	private double tPuInvincible;
	private double tPuSpeedUp;  //timerA
	private double tPuSlowDown; //timerB
	private double tPuInversed; //Timer1,2,3,4

	// Contains username.
	private string username;

	// Contains unique hash of the user as is known by the back-end.
	private string hash;

	// Contains the unique ID of the user as is known by the back-end.
	private int userId;

	// Contains the player ID (1, 2, 3 or 4).
	private int playerId;

	// Contains the color of the player.
	private Color color;

	// Contains the score.
	private int score;

	// Keeps track whether the user is alive or not.
	private bool alive;

	// Speed the shuttle moves forward with.
	private int speed;

	// Interval for spawning a trail cube (changes with speed).
	private double trailSpawnTime;

	// Holds the direction where the user moves to.
	private int direction;


	/**
	 * Dummy constructor.
	 **/
	public Player() {

		// Set some internal stuff.
		this.setInternals();
	}

	/**
	 * Constructor for setting up some things.
	 **/
	public Player(string username, string hash, int userId, int playerId, Color color) {

		this.username = username;
		this.hash = hash;
		this.userId = userId;
		this.playerId = playerId;
		this.color = color;

		// Set some internal stuff.
		this.setInternals();
	}


	/**
	 * Sets some internal stuff that really needs to be set before playing.
	 **/
	private void setInternals() {

		this.tPuInvincible = 0;
		this.score = 0;
		this.alive = true;
		this.speed = 3;
	}

	/**
	 * Sets the invincibility timer.
	 **/
	public Player setTimerPuInvincible(double t) {

		this.tPuInvincible = t;

		return this;
	}

	/**
	 * Gets the invincibility timer.
	 **/
	public double getTimerPuInvincible() {

		return this.tPuInvincible;
	}

	/**
	 * Sets the timer value for the duration to have extra speed
	 **/
	public Player setTimerPuSpeedUp(double t) {

		this.tPuSpeedUp = t;

		return this;
	}

	/**
	 * Returns timer value
	 **/
	public double getTimerPuSpeedUp() {

		return this.tPuSpeedUp;
	}

	/**
	 * Sets timer value of the duration to move slower than usual
	 **/
	public Player setTimerPuSlowDown(double t) {

		this.tPuSlowDown = t;

		return this;
	}

	/**
	 * Retrieves timer value
	 **/
	public double getTimerPuSlowDown() {

		return this.tPuSlowDown;
	}

	/**
	 * Sets value for inversed controls duration
	 **/
	public Player setTimerPuInversed(double t) {
		
		this.tPuInversed = t;
		
		return this;
	}
	
	/**
	 * Returns the inversed controls timer value
	 **/
	public double getTimerPuInversed() {
		
		return this.tPuInversed;
	}

	/**
	 * Sets the username.
	 **/
	public Player setUsername(string username) {

		this.username = username;

		return this;
	}

	/**
	 * Gets the username.
	 **/
	public string getUsername() {

		return this.username;
	}

	/**
	 * Sets the unique user hash (for auth).
	 **/
	public Player setHash(string hash) {

		this.hash = hash;

		return this;
	}

	/**
	 * Gets the unique user hash.
	 **/
	public string getHash() {

		return this.hash;
	}

	/**
	 * Sets the user ID
	 **/
	public Player setUserId(int userId) {

		this.userId = userId;

		return this;
	}

	/**
	 * Returns the user ID
	 **/
	public int getUserId() {

		return this.userId;
	}

	/**
	 * Sets the player ID
	 **/
	public Player setPlayerId(int playerId) {

		this.playerId = playerId;

		return this;
	}

	/**
	 * Returns the player ID
	 **/
	public int getPlayerId() {

		return this.playerId;
	}

	/**
	 * Sets the color of the player
	 **/
	public Player setColor(string color) {

		if (color == "red") {
			this.color = Color.red;
		}
		else if (color == "green") {
			this.color = Color.green;
		}
		else if (color == "yellow") {
			this.color = Color.yellow;
		}
		else if (color == "blue") {
			this.color = Color.blue;
		}
		else if (color == "white") {
			this.color = Color.white;
		}

		return this;
	}

	/**
	 * Returns the color as an instance of the Color class
	 **/
	public Color getColor() {

		return this.color;
	}

	/**
	 * Sets the score.
	 **/
	public Player setScore(int score) {

		this.score = score;

		return this;
	}

	/**
	 * Returns the score.
	 **/
	public int getScore() {

		return this.score;
	}

	/**
	 * Revives a player :D
	 **/
	public Player setIsAlive(bool a) {

		this.alive = a;

		return this;
	}

	/**
	 * Returns the 'alive' status
	 **/
	public bool isAlive() {

		return this.alive;
	}

	/**
	 * Sets the speed the shuttle moves forward with
	 **/
	public Player setSpeed(int spd) {

		if (spd == 2)
			this.trailSpawnTime = 0.12;

		if (spd == 3)
			this.trailSpawnTime = 0.08;

		if (spd == 4)
			this.trailSpawnTime = 0.06;

		this.speed = spd;

		return this;
	}

	/**
	 * Gets the shuttle movement speed
	 **/
	public int getSpeed() {

		return this.speed;
	}

	/**
	 * Sets the direction the shuttle needs to move to
	 **/
	public Player setDirection(int d) {

		this.direction = d;

		return this;
	}

	/**
	 * Returns the trail spawn time interval
	 **/
	public double getTrailSpawnTime() {

		return this.trailSpawnTime;
	}

	/**
	 * Returns the direction
	 **/
	public int getDirection() {

		return this.direction;
	}

	/**
	 * Customize the ToString() method
	 **/
	public override string ToString() {

		string str = "Name: " + this.username + 
					 ". uID: " + this.userId +
					 ". pID: " + this.playerId +
					 ". Hash: " + this.hash + 
				 	 ". Color: " + this.color;

		return str;
	}
}
