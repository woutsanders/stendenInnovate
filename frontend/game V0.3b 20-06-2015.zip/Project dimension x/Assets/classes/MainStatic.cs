﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


/**
 * Contains all main functionality that needs to be persistent
 * inbetween laps / rounds
 **/
public static class MainStatic {

	/**
	 * Player (and related) objects
	 **/
	public static int maxPlayers = 4; // Maximum players in the game (DO NOT CHANGE!).
	public static List<Player> players; // Holds all player 'entity' objects.

	/**
	 * Global trail timers and events
	 **/
	public static bool spawnTrail = false;
	public static double spawnTrailRate; // Number of cubes to spawn in seconds.
	public static double spawnTrailPause; // How long to wait before leaving a hole.
	public static double spawnTrailInterval = 0.08; // The fixed interval for timer.

	/**
	 * Unity3D On Stage objects
	 **/
	public static int turn = 300;
	public static Transform speler1;
	public static Transform speler2;
	public static Transform speler3;
	public static Transform speler4;
	public static Transform background;

	/**
	 * Socket data for tunneling controls.
	 * A separate socket for sending and receiving is required,
	 * due to some issues on the server side.
	 **/
	public static SocketHelper socketWriter;
	public static SocketHelper socketReader;
	public static string socketHost = "woutsanders.com";
	public static int socketWriterPort = 9990;
	public static int socketReaderPort = 9991;

	/**
	 * Some game starting statuses and timers
	 **/
	public static bool startGame = false; // To start, or not to start the game :)
	public static bool finishedGame = false; // True if the game is finished (handle to send player scores).
	public static int round = 1; // Number rounds / laps that have been made.
	public static int rounds = 3; // Number of rounds / laps to make.
	public static double start; // Timer to delay some animations after start.

	// How long the lap circle needs to spin.
	public static double tNewLapAnim = 4;
	
	// Score increment after each player object kill.
	public static int scoreAmount = 10;


	/**
	 * Sets some things that we really need.
	 **/
	public static void setupSockets() {

		MainStatic.socketWriter = new SocketHelper(MainStatic.socketHost, MainStatic.socketWriterPort);
		MainStatic.socketReader = new SocketHelper(MainStatic.socketHost, MainStatic.socketReaderPort);
	}

	/**
	 * Resets some properties when entering game mode or resetting levels
	 **/
	public static void resetStatics() {

		MainStatic.round = 1;
		MainStatic.tNewLapAnim = 0;
	}

	/**
	 * Adds score to players
	 **/
	public static void addScore(int amount) {

		foreach (Player player in MainStatic.players) {

			if (player.isAlive()) {
			
				int currScore = player.getScore();
				player.setScore (currScore + amount);
			}
		}
	}
}