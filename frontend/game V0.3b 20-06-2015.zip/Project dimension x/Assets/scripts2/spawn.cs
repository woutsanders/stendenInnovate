﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class spawn : MonoBehaviour {
	
	/*
	 * de score word niet opgehoogt bij de 3e death, ligt wss ergens bij toe die timer
	 */

	// MOVED TO MAIN STATIC
	public GameObject PowerUp;	//als je over een powerup gaat gaat je eigen karacter
	public GameObject SlowDown;
	public GameObject Inverse;
	public GameObject NoStops;

	// MOVED TO MAIN STATIC
	public double PUtimer;
	public double SlowTimer;
	public double InverseTimer;
	public double NoStopsTimer;

	// MOVED TO PLAYER CLASS
	public static double NoStopsTimer1 = 3;
	public static double NoStopsTimer2 = 3;
	public static double NoStopsTimer3 = 3;
	public static double NoStopsTimer4 = 3;
	public static double Timer1 = 3;
	public static double Timer2 = 3;
	public static double Timer3 = 3;
	public static double Timer4 = 3;
	public static int snelheid1 = 3;
	public static int snelheid2 = 3;
	public static int snelheid3 = 3;
	public static int snelheid4 = 3;

	// MOVED TO PLAYER CLASS
	public static bool player1_alive = true;
	public static bool player2_alive = true;
	public static bool player3_alive = true;
	public static bool player4_alive = true;

	// MOVED TO MAIN STATIC
	public int turn = 300;
	public Transform speler1;
	public Transform speler2;
	public Transform speler3;
	public Transform speler4;
	public Transform achtergrond;
	public double start;

	// Used for animating lap counter (MOVED TO MAIN STATIC)
	public Transform buiten_circle;
	public Transform middel_circle;
	public Transform inner_circle;

	// Text objects for the stage (TBM)
	public Text speler1_score;
	public Text speler2_score;
	public Text speler3_score;
	public Text speler4_score;

	public Text speler1_username_text;
	public Text speler2_username_text;
	public Text speler3_username_text;
	public Text speler4_username_text;
	
	
	// MOVED TO PLAYER CLASS
	public int score_of_player1;
	public int score_of_player2;
	public int score_of_player3;
	public int score_of_player4;

	// Unused variable?
	public int score_amount = 10;

	public Text gameround_text;
	
	public static double animatie_timer = 4;
	public static int players_dead = 0;
	public static int game_round = 0;
	public int roundNum;
	public float waitsec = 1.0f;


	AudioClass playsound = new AudioClass();

	
	// Maak de variabelen aan die buiten de scenes gebruikt kunnen worden
	
	//Hier set ik 4 score variabelen
	void set_scoreprefs(){
		PlayerPrefs.SetInt("Speler1_score" , score_of_player1);
		PlayerPrefs.SetInt("Speler2_score" , score_of_player2);
		PlayerPrefs.SetInt("Speler3_score" , score_of_player3);
		PlayerPrefs.SetInt("Speler4_score" , score_of_player4);
	}

	// MOVED TO MAIN STATIC
	public void addscore (int amount) {
		if (player1_alive == true) {
			score_of_player1 = PlayerPrefs.GetInt ("Speler1_score");
			score_of_player1 = score_of_player1 + amount;
			PlayerPrefs.SetInt ("Speler1_score", score_of_player1);
			
		}
		
		if (player2_alive == true) {
			score_of_player2 = PlayerPrefs.GetInt ("Speler2_score");
			score_of_player2 = score_of_player2 + amount;
			PlayerPrefs.SetInt ("Speler2_score", score_of_player2);
		}
		
		if (player3_alive == true) {
			score_of_player3 = PlayerPrefs.GetInt ("Speler3_score");
			score_of_player3 = score_of_player3 + amount;
			PlayerPrefs.SetInt ("Speler3_score", score_of_player3);
		}
		
		if (player4_alive == true) {
			score_of_player4 = PlayerPrefs.GetInt ("Speler4_score");
			score_of_player4 = score_of_player4 + amount;
			PlayerPrefs.SetInt ("Speler4_score", score_of_player4);
		}
	}
	
	public void fillscores(){
		speler1_score.text = PlayerPrefs.GetInt ("Speler1_score").ToString();
		speler2_score.text = PlayerPrefs.GetInt ("Speler2_score").ToString();
		speler3_score.text = PlayerPrefs.GetInt ("Speler3_score").ToString();
		speler4_score.text = PlayerPrefs.GetInt ("Speler4_score").ToString();
		
		
	}

	// MOVED TO MAIN STATIC
	void loadlevel(){
		Application.LoadLevel(1);
		print ("klaar met wachten");
		players_dead = 0;
		animatie_timer = 0;
		player1_alive = true;
		player2_alive = true;
		player3_alive = true;
		player4_alive = true;
	}
	
	void fill_names(){
		
		speler1_username_text.text =  PlayerPrefs.GetString ("Speler1_Username").ToString();
		speler2_username_text.text =  PlayerPrefs.GetString ("Speler2_Username").ToString();
		speler3_username_text.text =  PlayerPrefs.GetString ("Speler3_Username").ToString();
		speler4_username_text.text =  PlayerPrefs.GetString ("Speler4_Username").ToString();
	}

	// MOVED TO MAIN STATIC
	void loadpool() {
		//	waitsec -= Time.deltaTime;
		//if (waitsec < 0) {
		Application.LoadLevel(2);
		print ("klaar met wachten");
		//	}
		
	}
	
	void Level_Ophogen () {
//		MainStatic.round = PlayerPrefs.GetInt("LevelNummer");
//		MainStatic.round++;
//		PlayerPrefs.SetInt("LevelNummer" , MainStatic.round);
//		gameround_text.text = PlayerPrefs.GetInt("LevelNummer").ToString();
	}
	
	
	void Start(){
		playsound.PlayAudio(5, "background_sound");

		Level_Ophogen ();
		fill_names ();
		fillscores ();
		
		
	}
	
	
	void Update () {

		if (players_dead >= 3) {
			game_round++;
			if (game_round < 3) {
				loadlevel();
			} else if (game_round >= 3) {	
				loadpool();
			}
		}
		
		fillscores ();

		// MOVED
		if (animatie_timer < 3.5) 
		{
			buiten_circle.transform.Rotate (Vector3.forward * 100 * Time.deltaTime);
			middel_circle.transform.Rotate (-Vector3.forward * 100 * Time.deltaTime);
			inner_circle.transform.Rotate (Vector3.forward * 100 * Time.deltaTime);
		}

		// MOVED
		animatie_timer += Time.deltaTime;
		NoStopsTimer1 += Time.deltaTime;
		NoStopsTimer2 += Time.deltaTime;
		NoStopsTimer3 += Time.deltaTime;
		NoStopsTimer4 += Time.deltaTime;

		// MOVED
		PUtimer += Time.deltaTime;
		if (PUtimer > 4) {	
			SpawnObject();
			PUtimer = 0;
		}

		// MOVED
		SlowTimer += Time.deltaTime;
		if (SlowTimer > 4) {
			SpawnSlowDown();
			SlowTimer = 0;
		}

		// MOVED
		Timer1 += Time.deltaTime;
		Timer2 += Time.deltaTime;
		Timer3 += Time.deltaTime;
		Timer4 += Time.deltaTime;

		// MOVED
		InverseTimer += Time.deltaTime;
		if (InverseTimer > 4) {
			SpawnInverse();
			InverseTimer = 0;
		}

		// MOVED
		NoStopsTimer += Time.deltaTime;
		if (NoStopsTimer > 4) {
			SpawnNoStops();
			NoStopsTimer = 0;
		}

		// MOVED
		achtergrond.transform.Rotate (Vector3.up * 2 * Time.deltaTime);
		start += Time.deltaTime;
		if (start > 2) {
			if (player1_alive == true) {
				speler1.transform.Translate (Vector3.up * (snelheid1 + 1) * Time.deltaTime);
				if (Timer1 >= 2) {
					if (Input.GetKey (KeyCode.Q)) {	// A key - naar links
						speler1.transform.Rotate (Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.E)) {	// D key - naar rechts
						speler1.transform.Rotate (-Vector3.forward * turn * Time.deltaTime);	
					}
				} else if (Timer1 < 2) {
					if (Input.GetKey (KeyCode.E)) {	// A key - naar links
						speler1.transform.Rotate (Vector3.forward * turn * Time.deltaTime);
					}
					if (Input.GetKey (KeyCode.Q)) {	// D key - naar rechts
						speler1.transform.Rotate (-Vector3.forward * turn * Time.deltaTime);	
					}
				}
			}
			
			if (player2_alive == true) {
				speler2.transform.Translate (Vector3.up * (snelheid2 + 1) * Time.deltaTime);
				if (Timer2 >= 2) {
					if (Input.GetKey (KeyCode.A)) {	// Links - naar links
						speler2.transform.Rotate (Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.D)) {	// Rechts - naar rechts
						speler2.transform.Rotate (-Vector3.forward * turn * Time.deltaTime);	
					}
				} else if (Timer2 < 2) {
					if (Input.GetKey (KeyCode.D)) {	// Links - naar links
						speler2.transform.Rotate (Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.A)) {	// Rechts - naar rechts
						speler2.transform.Rotate (-Vector3.forward * turn * Time.deltaTime);	
					}
				}
			}
			
			if (player3_alive == true) {
				speler3.transform.Translate (Vector3.up * (snelheid3 + 1) * Time.deltaTime);
				if (Timer3 >= 2) {
					if (Input.GetKey (KeyCode.Z)) {	// Links - naar links
						speler3.transform.Rotate(Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.C)) {	// Rechts - naar rechts
						speler3.transform.Rotate(-Vector3.forward * turn * Time.deltaTime);	
					}
				} else if (Timer3 < 2) {
					if (Input.GetKey (KeyCode.C)) {	// Links - naar links
						speler3.transform.Rotate(Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.Z)) {	// Rechts - naar rechts
						speler3.transform.Rotate(-Vector3.forward * turn * Time.deltaTime);	
					}
				}
			}
			//player 4 hieronder
			
			if (player4_alive == true) {
				speler4.transform.Translate (Vector3.up * (snelheid4 + 1) * Time.deltaTime);
				if (Timer4 >= 2) {
					if (Input.GetKey (KeyCode.LeftArrow)) {	// Links - naar links
						speler4.transform.Rotate (Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.RightArrow)) {	// Rechts - naar rechts
						speler4.transform.Rotate (-Vector3.forward * turn * Time.deltaTime);	
					}
				} else if (Timer3 < 2) {
					if (Input.GetKey (KeyCode.RightArrow)) {	// Links - naar links
						speler4.transform.Rotate (Vector3.forward * turn * Time.deltaTime);	
					}
					if (Input.GetKey (KeyCode.LeftArrow)) {	// Rechts - naar rechts
						speler4.transform.Rotate (-Vector3.forward * turn * Time.deltaTime);	
					}
				}
			}
		}
	}

	// MOVED TO MAIN STATIC
	void SpawnObject() {
		
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(PowerUp, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}

	// MOVED TO MAIN STATIC
	void SpawnSlowDown() {
		
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(SlowDown, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}

	// MOVED TO MAIN STATIC
	void SpawnInverse() {
		
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate(Inverse, new Vector3(x,y,0), Quaternion.identity); //as GameObject;
	}

	// MOVED TO MAIN STATIC
	void SpawnNoStops() {
		float x = Random.Range (-14, 25);
		float y = Random.Range (-14, 14);
		Instantiate (NoStops, new Vector3 (x, y, 0), Quaternion.identity); //as GameObject;
	}
}
