﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


/**
 * Binded to every trail cube and invisible game wall
 * to handle player kills
 **/
public class KillObject : MonoBehaviour {

	// Timer to prevent spawn issues.
	public double timer;

	// Handles audio.
	AudioClass playsound = new AudioClass();
	
	void Update () {

		// Update timer in seconds.
		this.timer += Time.deltaTime;
	}

	/**
	 * Help! Another player collided, what to do?
	 **/
	void OnTriggerEnter(Collider other) {

		// Loop through players.
		foreach (Player player in MainStatic.players) {

			if (player.isAlive()) {

				// Only kill player if he isn't invincible and if the collider IS
				// the player!
				if (player.getTimerPuInvincible() > PowerUps.tPuInvincibleThreshold
				    && this.timer > 0.07
				    && other.gameObject.name == "Player" + player.getPlayerId())
				{
					playsound.PlayAudio(0, "soundeffect_explosion");
					player.setIsAlive(false);

					// Add scores to all alive players.
					MainStatic.addScore(MainStatic.scoreAmount);
				}
			}
		} // End-foreach
	}
	
}
