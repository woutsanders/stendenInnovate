﻿using UnityEngine;
using System.Collections;
/* Patrick luchies
 * Datum: 16-6-2015
*/

/**
 * Handles all audio files
 **/
public class AudioClass {

	/**
	 * Plays the requested audio
	 **/
	public void PlayAudio(int clip, string audioobject) {

		// Initialize some audio components.
		AudioSource audiosource;
		AudioClip[] geluid;

		// Bind audio.
		audiosource = Camera.main.transform.Find (audioobject).GetComponent<AudioSource> ();

		// Set up audio array...
		geluid = new AudioClip[] {

			//Hier volgt en array. Begin bij 0

			//Voor de game level
			(AudioClip)Resources.Load ("geluid/ontplof") as AudioClip,     //Zodra de speler dood gaat  
			(AudioClip)Resources.Load ("geluid/background_sound") as AudioClip,  //Achtergrond muziek  
			(AudioClip)Resources.Load ("geluid/powerup") as AudioClip,	   //bij het pakken van een powerup

			//Voor de pool scene
			(AudioClip)Resources.Load ("geluid/aftel") as AudioClip,    //Aftel geluid
			(AudioClip)Resources.Load ("geluid/start") as AudioClip,	   //Geluid als aftellen klaar is
			(AudioClip)Resources.Load ("geluid/background_sound") as AudioClip	       //Achtergrond geluid voor de pool scene
		};

		// Specify which clip to play and play it.
		audiosource.clip = geluid [clip];
		audiosource.Play ();
	}
}