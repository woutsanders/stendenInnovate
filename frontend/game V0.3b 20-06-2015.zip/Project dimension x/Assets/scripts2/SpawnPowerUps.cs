using UnityEngine;
using System.Collections;


/**
 * Binded to every powerUp, handles the destroy
 * functionality of each powerUp to clean up the scene
 * if a player crosses one.
 **/
public class SpawnPowerUps : MonoBehaviour {

	// Explosion effect.
	public GameObject Explosion;

	// Handles powerUp audio.
	AudioClass playsound = new AudioClass();

	/**
	 * What to do if a player picks up a powerUp
	 **/
	void OnTriggerEnter(Collider other)
	{
		foreach (Player player in MainStatic.players) {

			if (other.gameObject.name == "Player" + player.getPlayerId()) {

				playsound.PlayAudio(2, "soundeffect_powerup");

				// Show effect and remove powerUp from stage.
				Instantiate (Explosion, transform.position, new Quaternion());
				Destroy(gameObject);
			}
		}
	}
}

		



